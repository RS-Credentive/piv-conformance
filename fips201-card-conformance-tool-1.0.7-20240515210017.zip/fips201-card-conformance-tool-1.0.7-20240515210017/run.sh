java -Djava.security.debug=certpath -jar gov.gsa.pivconformance.gui-1.0.7-shadow.jar >>console.log 2>&1
